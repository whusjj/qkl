import os
import torch
from argparse import ArgumentParser
from pprint import pprint
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint, LearningRateMonitor
from pytorch_lightning.strategies import DDPStrategy
from pytorch_lightning.profilers import AdvancedProfiler
from pytorch_lightning.loggers import TensorBoardLogger
from train import Model
from data import GraphDataModule, get_dataset
from pytorch_lightning.cli import LightningCLI
import faulthandler
# 在import之后直接添加以下启用代码即可
faulthandler.enable()

def add_parser(parser): #把直接的命令行参数收集
    parser.add_argument("--num_workers", type=int, default=8)
    parser.add_argument("--seed", type=int, default=12)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--dataset_name", type=str, default="Synthetic-Barabasi-Albert")
    parser.add_argument("--devices", type=int, default=0)
    parser.add_argument("--default_root_dir", type=str, default="../exps/12/dense/default")
    parser.add_argument("--tot_updates", type=int, default=3000)
    parser.add_argument("--warmup_updates", type=int, default=1000)
    parser.add_argument("--num_graphs", type=int, default=1280)
    parser.add_argument("--min_num_nodes", type=int, default=10)
    parser.add_argument("--max_num_nodes", type=int, default=15)
    parser.add_argument("--min_num_edges_attached", type=int, default=2)
    parser.add_argument("--max_num_edges_attached", type=int, default=3)
    parser.add_argument("--check_val_every_n_epoch", type=int, default=10)
    parser.add_argument("--orf_node_id", action='store_true')
    parser.add_argument("--orf_node_id_dim", type=int, default=48)
    parser.add_argument("--not_first_order", action='store_true')
    parser.add_argument("--peak_lr", type=float, default=1e-4)
    parser.add_argument("--end_lr", type=float, default=1e-9)
    parser.add_argument("--dense_setting", action='store_true')
    parser.add_argument("--save_display", action='store_true')
    parser.add_argument("--n_layers", type=int, default=0)
    parser.add_argument("--dim_hidden", type=int, default=1024)
    parser.add_argument("--dim_ff", type=int, default=1024)
    parser.add_argument("--dim_qk", type=int, default=128)
    parser.add_argument("--dim_v", type=int, default=128)
    parser.add_argument("--input_dropout_rate", type=float, default=0.1)
    parser.add_argument("--dropout_rate", type=float, default=0.0)
    parser.add_argument("--checkpoint_path", type=str, default="")
    parser.add_argument("--test", action='store_true')
    parser.add_argument("--type_id", action='store_true')
    parser.add_argument("--accelerator", type=str, default="ddp")
    parser.add_argument("--precision", type=int, default=32)
    parser.add_argument("--gradient_clip_val", type=float, default=5.0)
    parser.add_argument("--lap_node_id", action='store_true')
    parser.add_argument("--lap_node_id_dim", type=int, default=40)
    parser.add_argument("--rand_node_id", action='store_true')
    parser.add_argument("--rand_node_id_dim", type=int, default=48)
    parser.add_argument("--strategy", type=str, default="ddp_find_unused_parameters_true")
    parser.add_argument('--profile', action='store_true', default=False)
    parser.add_argument('--baseline', default=None)
    parser.add_argument('--version', type=int, default=None)
    parser.add_argument('--last_layer_n_heads', type=int, default=16)
    parser.add_argument('--validate', action='store_true', default=False)
    parser.add_argument('--list_struct_idx_str', type=str, default="1 2 3 4 5 6 7 8 9 10 11 12 13 14 15")
    parser.add_argument('--save_display_interval', type=int, default=50)
    parser.add_argument('--n_heads', type=int, default=16)
    parser.add_argument('--weight_decay', type=float, default=0.)
    return parser


    

def cli_main():
    # ------------
    # args
    # ------------
    parser = ArgumentParser()
    parser = add_parser(parser)
    args = parser.parse_args()
    args.max_steps = args.tot_updates + 1
    pl.seed_everything(args.seed)
    print(args.batch_size)
    # ------------
    # data
    # ------------
    dm = GraphDataModule(num_workers=args.num_workers,batch_size=args.batch_size,num_graphs=args.num_graphs,min_num_nodes=args.min_num_nodes,max_num_nodes=args.max_num_nodes,
                        min_num_edges_attached=args.min_num_edges_attached,max_num_edges_attached=args.max_num_edges_attached,seed=args.seed)

    # ------------
    # training
    # ------------
    metric = 'train_loss'
    logger_dir = args.default_root_dir + f'/tb_log'
    logger_name = 'default'
    os.makedirs(logger_dir, exist_ok=True)

    ckpt_dirpath = args.default_root_dir + f'/checkpoints'
    os.makedirs(ckpt_dirpath, exist_ok=True)

    checkpoint_callback = ModelCheckpoint(
        monitor=metric,
        dirpath=ckpt_dirpath,
        filename=args.dataset_name + '-{epoch:03d}-{' + metric + ':.4f}',
        save_top_k=100,
        mode=get_dataset(dm.dataset_name)['metric_mode'],
        save_last=True,
    )
    logger = TensorBoardLogger(save_dir=logger_dir, name='')
    if args.profile:
        trainer = pl.Trainer(accelerator=args.accelerator, strategy="ddp_find_unused_parameters_true", devices=args.devices,precision=args.precision,
                                                profiler=AdvancedProfiler(filename='perf.txt'), logger=logger,max_steps=args.max_steps,gradient_clip_val=args.gradient_clip_val,
                                                default_root_dir=args.default_root_dir,
                                                check_val_every_n_epoch=args.check_val_every_n_epoch)
    else:
        trainer = pl.Trainer(accelerator=args.accelerator, strategy="ddp_find_unused_parameters_true", devices=args.devices,precision=args.precision,
                                                logger=logger,max_steps=args.max_steps,gradient_clip_val=args.gradient_clip_val,default_root_dir=args.default_root_dir,
                                                check_val_every_n_epoch=args.check_val_every_n_epoch)

    trainer.callbacks.append(checkpoint_callback)
    trainer.callbacks.append(LearningRateMonitor(logging_interval='step'))

    attn_save_dir = args.default_root_dir + f'/attn'
    os.makedirs(attn_save_dir, exist_ok=True)

    # ------------
    # model
    # ------------
    if args.checkpoint_path != '':
        model = Model.load_from_checkpoint(
            args.checkpoint_path,
            strict=False,
            baseline=args.baseline,
            batch_size=args.batch_size,
            dense_setting=args.dense_setting,
            attn_save_dir=attn_save_dir,
            n_layers=args.n_layers,
            dim_hidden=args.dim_hidden,
            dim_qk=args.dim_qk,
            dim_v=args.dim_v,
            dim_ff=args.dim_ff,
            n_heads=args.n_heads,
            last_layer_n_heads=args.last_layer_n_heads,
            input_dropout_rate=args.input_dropout_rate,
            dropout_rate=args.dropout_rate,
            weight_decay=args.weight_decay,
            dataset_name=dm.dataset_name,
            warmup_updates=args.warmup_updates,
            tot_updates=args.tot_updates,
            peak_lr=args.peak_lr,
            end_lr=args.end_lr,
            list_struct_idx_str=args.list_struct_idx_str,
            lap_node_id=args.lap_node_id,
            lap_node_id_dim=args.lap_node_id_dim,
            rand_node_id=args.rand_node_id,
            rand_node_id_dim=args.rand_node_id_dim,
            orf_node_id=args.orf_node_id,
            orf_node_id_dim=args.orf_node_id_dim,
            type_id=args.type_id,
            not_first_order=args.not_first_order,
            maximum_node=dm.maximum_node,
            save_display=args.save_display,
        )
    else:
        model = Model(
            baseline=args.baseline,
            dense_setting=args.dense_setting,
            batch_size=args.batch_size,
            attn_save_dir=attn_save_dir,
            n_layers=args.n_layers,
            dim_hidden=args.dim_hidden,
            dim_qk=args.dim_qk,
            dim_v=args.dim_v,
            dim_ff=args.dim_ff,
            n_heads=args.n_heads,
            last_layer_n_heads=args.last_layer_n_heads,
            input_dropout_rate=args.input_dropout_rate,
            dropout_rate=args.dropout_rate,
            weight_decay=args.weight_decay,
            dataset_name=dm.dataset_name,
            warmup_updates=args.warmup_updates,
            tot_updates=args.tot_updates,
            peak_lr=args.peak_lr,
            end_lr=args.end_lr,
            list_struct_idx_str=args.list_struct_idx_str,
            lap_node_id=args.lap_node_id,
            lap_node_id_dim=args.lap_node_id_dim,
            rand_node_id=args.rand_node_id,
            rand_node_id_dim=args.rand_node_id_dim,
            orf_node_id=args.orf_node_id,
            orf_node_id_dim=args.orf_node_id_dim,
            type_id=args.type_id,
            not_first_order=args.not_first_order,
            maximum_node=dm.maximum_node,
            save_display=args.save_display,
        )
    if args.test:
        print("test")
        result = trainer.test(model, datamodule=dm)
        pprint(result)
    elif args.validate:
        print("validate")
        result = trainer.validate(model, datamodule=dm)
        pprint(result)
    else:  # train
        print("train")
        trainer.fit(model, datamodule=dm)


if __name__ == '__main__':
    cli_main()
