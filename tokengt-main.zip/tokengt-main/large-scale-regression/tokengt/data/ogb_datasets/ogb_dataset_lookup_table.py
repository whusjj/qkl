"""
Modified from https://github.com/microsoft/Graphormer
"""

from typing import Optional
# from ogb.lsc.pcqm4mv2_pyg import PygPCQM4Mv2Dataset
from .pcqm4mv2_pyg import PygPCQM4Mv2Dataset,BLOCKCHAINDataset
from torch_geometric.data import Dataset
from ..pyg_datasets import TokenGTPYGDataset
import torch.distributed as dist
import os
import torch 
from torch_geometric.data import Data

class MyPygPCQM4Mv2Dataset(PygPCQM4Mv2Dataset):
    def download(self):
        if not dist.is_initialized() or dist.get_rank() == 0:
            super(MyPygPCQM4Mv2Dataset, self).download()
        if dist.is_initialized():
            dist.barrier()

    def process(self):
        print('process')
        if not dist.is_initialized() or dist.get_rank() == 0:
            print('process')
            super(MyPygPCQM4Mv2Dataset, self).process()
        if dist.is_initialized():
            dist.barrier()

class MyBLOCKCHAINDataset(BLOCKCHAINDataset):
    def download(self):
        if not dist.is_initialized() or dist.get_rank() == 0:
            super(MyBLOCKCHAINDataset, self).download()
        if dist.is_initialized():
            dist.barrier()

    def process(self):
        print('process')
        if not dist.is_initialized() or dist.get_rank() == 0:
            print('process')
            super(MyBLOCKCHAINDataset, self).process()
        if dist.is_initialized():
            dist.barrier()


class OGBDatasetLookupTable:
    @staticmethod
    def GetOGBDataset(dataset_name: str, seed: int) -> Optional[Dataset]:
        inner_dataset = None
        train_idx = None
        valid_idx = None
        test_idx = None
        if dataset_name == "pcqm4mv2":
            os.system("mkdir -p dataset/pcqm4m-v2/")
            os.system("touch dataset/pcqm4m-v2/RELEASE_v1.txt")
            inner_dataset = MyPygPCQM4Mv2Dataset()
            train = torch.load(f"/root/autodl-tmp/tokengt-main/large-scale-regression/scripts/dataset/pcqm4m-v2/split_dict.pt")
            print(train)
            idx_split = inner_dataset.get_idx_split()
            train_idx = idx_split["train"]
            valid_idx = idx_split["valid"]
            test_idx = idx_split["test-dev"]
        elif dataset_name == "blockchain":
            inner_dataset = MyBLOCKCHAINDataset()
            idx_split = inner_dataset.get_idx_split()
            train_idx = idx_split["train"]
            valid_idx = idx_split["valid"]
            test_idx = idx_split["test-dev"]
        else:
            raise ValueError(f"Unknown dataset name {dataset_name} ")
        return (
            None
            if inner_dataset is None
            else TokenGTPYGDataset(
                inner_dataset, seed, train_idx, valid_idx, test_idx
            )
        )
